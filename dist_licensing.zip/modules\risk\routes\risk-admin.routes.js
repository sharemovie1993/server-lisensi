"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.riskAdminRoutes = riskAdminRoutes;
const client_1 = require("@prisma/client");
const admin_routes_1 = require("../../../routes/admin.routes");
const prisma = new client_1.PrismaClient();
async function riskAdminRoutes(fastify) {
    fastify.get('/api/admin/risk/overview', {
        preHandler: [admin_routes_1.verifyAdmin],
        handler: async (request, reply) => {
            try {
                const queryProduct = request.query;
                const productId = queryProduct.productId && queryProduct.productId !== 'all' ? (queryProduct.productId === 'absenta' ? 'platform-absenta' : queryProduct.productId) : undefined;
                const licenseFilter = { requestedSlug: { not: null } };
                if (productId) {
                    licenseFilter.productId = productId;
                }
                const matchingLicenses = await prisma.license.findMany({
                    where: licenseFilter,
                    select: { id: true, schoolName: true }
                });
                const matchingIds = matchingLicenses.map(l => l.id);
                const [totalTenants, scoredTenants, grouped, topTen] = await Promise.all([
                    matchingLicenses.length,
                    prisma.platformRisk.count({ where: { tenantId: { in: matchingIds } } }),
                    prisma.platformRisk.groupBy({
                        where: { tenantId: { in: matchingIds } },
                        by: ['riskLevel'],
                        _count: { _all: true },
                    }),
                    prisma.platformRisk.findMany({
                        where: { tenantId: { in: matchingIds } },
                        orderBy: [{ riskScore: 'desc' }, { updatedAt: 'desc' }],
                        take: 10,
                    }),
                ]);
                // Get tenant details for the top 10
                const licenseMap = new Map(matchingLicenses.map(l => [l.id, l.schoolName]));
                const byLevel = {};
                for (const row of grouped) {
                    byLevel[String(row.riskLevel)] = Number(row?._count?._all ?? 0);
                }
                return reply.status(200).send({
                    success: true,
                    message: 'Tenant risk overview retrieved successfully',
                    data: {
                        total_tenant: totalTenants,
                        uncalculated_tenant: Math.max(0, totalTenants - scoredTenants),
                        HEALTHY: byLevel.HEALTHY ?? 0,
                        WARNING: byLevel.WARNING ?? 0,
                        HIGH_RISK: byLevel.HIGH_RISK ?? 0,
                        CRITICAL: byLevel.CRITICAL ?? 0,
                        top_10: topTen.map((r) => ({
                            tenant_id: r.tenantId,
                            tenant_name: licenseMap.get(r.tenantId) || 'Unknown',
                            risk_score: r.riskScore,
                            risk_level: r.riskLevel,
                            last_calculated_at: r.lastCalculatedAt,
                        })),
                    },
                });
            }
            catch (err) {
                return reply.status(500).send({ success: false, message: err.message });
            }
        },
    });
    fastify.get('/api/admin/risk/tenant/:id', {
        preHandler: [admin_routes_1.verifyAdmin],
        handler: async (request, reply) => {
            try {
                const { id } = request.params;
                if (!id) {
                    return reply.status(400).send({ success: false, code: 'VALIDATION_ERROR', message: 'tenant id is required' });
                }
                const [risk, license] = await Promise.all([
                    prisma.platformRisk.findUnique({
                        where: { tenantId: id },
                    }),
                    prisma.license.findUnique({
                        where: { id },
                        select: { schoolName: true }
                    })
                ]);
                if (!risk) {
                    return reply.status(404).send({ success: false, message: 'Risk profile not found for this tenant.' });
                }
                return reply.status(200).send({
                    success: true,
                    message: 'Tenant risk retrieved successfully',
                    data: {
                        score: {
                            tenant_id: risk.tenantId,
                            tenant_name: license?.schoolName || 'Unknown',
                            risk_score: risk.riskScore,
                            risk_level: risk.riskLevel,
                            email_failure_rate: risk.emailFailureRate,
                            payment_failure_rate: risk.paymentFailureRate,
                            last_calculated_at: risk.lastCalculatedAt,
                        },
                        recent_events: [] // stub event logs
                    }
                });
            }
            catch (err) {
                return reply.status(500).send({ success: false, message: err.message });
            }
        },
    });
}
