"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.heartbeatRoutes = void 0;
const client_1 = require("@prisma/client");
const api_key_handshake_middleware_1 = require("../middlewares/api-key-handshake.middleware");
const prisma = new client_1.PrismaClient();
const heartbeatRoutes = async (fastify) => {
    fastify.post('/api/platform/heartbeat', { preHandler: api_key_handshake_middleware_1.apiKeyHandshakeMiddleware }, async (request, reply) => {
        try {
            const license = request.license;
            const { activeUsers, dbSize, memoryUsage, lastTapped, deployMode, schoolName, appDomain, hostname, osType, tenants } = request.body;
            if (typeof activeUsers === 'undefined' || typeof dbSize === 'undefined' || typeof memoryUsage === 'undefined') {
                return reply.status(400).send({ success: false, message: 'Invalid payload metrics.' });
            }
            // 0. Update the telemetry directly to the License model
            const updateData = {
                lastHeartbeatAt: new Date(),
                deployMode: deployMode || 'local',
                activeUsers: Number(activeUsers),
                dbSize: Number(dbSize),
                memoryUsage: Number(memoryUsage),
                lastTapped: new Date(lastTapped)
            };
            if (schoolName && schoolName.trim()) {
                updateData.schoolName = schoolName.trim();
            }
            if (hostname && hostname.trim()) {
                updateData.activeHostname = hostname.trim();
            }
            if (osType && osType.trim()) {
                updateData.activeOs = osType.trim();
            }
            if (appDomain && appDomain.trim()) {
                const cleanDomain = appDomain.trim().toLowerCase();
                const domainParts = cleanDomain.split('.');
                const isSubdomain = cleanDomain.endsWith('.absenta.id') && domainParts.length >= 3;
                if (isSubdomain) {
                    updateData.requestedSlug = domainParts[0];
                    updateData.customDomain = null;
                }
                else {
                    updateData.requestedSlug = null;
                    updateData.customDomain = cleanDomain;
                }
            }
            await prisma.license.update({
                where: { id: license.id },
                data: updateData
            });
            // 0.5 Sync tenant list from multi-tenant server into subscriptions table
            if (tenants && Array.isArray(tenants) && tenants.length > 0) {
                const existingSubs = await prisma.subscription.findMany({
                    where: { licenseId: license.id },
                    select: { id: true, schoolName: true }
                });
                for (const t of tenants) {
                    const plainName = t.name ? t.name.trim() : '';
                    if (!plainName)
                        continue;
                    const existing = existingSubs.find(s => s.schoolName.split('|')[0].trim() === plainName);
                    if (existing) {
                        // Update existing subscription to include subdomain if missing
                        if (t.subdomain && !existing.schoolName.includes('|')) {
                            await prisma.subscription.update({
                                where: { id: existing.id },
                                data: { schoolName: `${plainName}|${t.subdomain}` }
                            });
                        }
                        continue;
                    }
                    // Create a placeholder subscription for this school if not already tracked
                    const dbSchoolName = t.subdomain ? `${plainName}|${t.subdomain}` : plainName;
                    await prisma.subscription.create({
                        data: {
                            licenseId: license.id,
                            schoolName: dbSchoolName,
                            productId: license.productId,
                            planId: license.planId || 'saas-node',
                            status: 'active',
                            startDate: new Date().toISOString().split('T')[0],
                            endDate: license.expiresAt
                        }
                    });
                }
            }
            // 1. Create TenantMetrics entry
            const metric = await prisma.tenantMetrics.create({
                data: {
                    tenantId: license.id,
                    activeUsers: Number(activeUsers),
                    dbSize: Number(dbSize),
                    memoryUsage: Number(memoryUsage),
                    lastTapped: new Date(lastTapped)
                }
            });
            // 2. Perform Tenant Churn Risk assessment
            // Simple heuristic: If there are 0 active users, risk score is high (80). Otherwise it is healthy (10).
            const riskScore = activeUsers === 0 ? 80 : 10;
            const riskLevel = riskScore >= 70 ? 'HIGH_RISK' : 'HEALTHY';
            await prisma.platformRisk.upsert({
                where: { tenantId: license.id },
                create: {
                    tenantId: license.id,
                    riskScore,
                    riskLevel,
                    emailFailureRate: 0,
                    paymentFailureRate: 0,
                    lastCalculatedAt: new Date()
                },
                update: {
                    riskScore,
                    riskLevel,
                    lastCalculatedAt: new Date()
                }
            });
            // 3. Perform Upgrade Intelligence assessment
            // Simple heuristic: If school size is large and active users grow, trigger upgrade intelligence
            const intentScore = activeUsers > 100 ? 75 : 30;
            const intentLevel = intentScore >= 70 ? 'HIGH' : 'LOW';
            await prisma.upgradeIntelligence.upsert({
                where: { tenantId: license.id },
                create: {
                    tenantId: license.id,
                    intentScore,
                    intentLevel,
                    usageGrowthPercent: 5.0,
                    lastCalculatedAt: new Date()
                },
                update: {
                    intentScore,
                    intentLevel,
                    lastCalculatedAt: new Date()
                }
            });
            return reply.send({
                success: true,
                message: 'Heartbeat metrics processed successfully.',
                metricId: metric.id
            });
        }
        catch (err) {
            fastify.log.error('[Heartbeat Error]', err.message);
            return reply.status(500).send({ success: false, message: 'Failed to process heartbeat: ' + err.message });
        }
    });
};
exports.heartbeatRoutes = heartbeatRoutes;
