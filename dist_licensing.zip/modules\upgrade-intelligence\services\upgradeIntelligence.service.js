"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.upgradeIntelligenceService = void 0;
exports.upgradeIntelligenceService = {
    normalizeMonth(date) {
        return new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), 1, 0, 0, 0, 0));
    },
    monthKeyUtc(date) {
        return this.normalizeMonth(date).toISOString().slice(0, 7);
    },
    async getOverview(db, _lastNMonths = 12) {
        const list = await db.upgradeIntelligence.findMany({
            orderBy: { intentScore: 'desc' },
            take: 20
        });
        const licenses = await db.license.findMany({
            where: { id: { in: list.map(x => x.tenantId) } },
            select: { id: true, schoolName: true }
        });
        const licenseMap = new Map(licenses.map(l => [l.id, l.schoolName]));
        const distribution = {
            LOW: list.filter(x => x.intentLevel === 'LOW').length,
            MEDIUM: list.filter(x => x.intentLevel === 'MEDIUM').length,
            HIGH: list.filter(x => x.intentLevel === 'HIGH').length,
        };
        return {
            latest_month: this.monthKeyUtc(new Date()),
            funnels: [
                {
                    month: this.monthKeyUtc(new Date()),
                    intent_count: list.filter(x => x.intentScore >= 70).length,
                    invoice_created_count: 0,
                    invoice_paid_count: 0,
                    upgrade_applied_count: 0,
                    conversion_rate: 0
                }
            ],
            intent_distribution: Object.entries(distribution).map(([level, count]) => ({
                intent_level: level,
                _count: { _all: count }
            })),
            top_hot_tenants: list.slice(0, 10).map(t => ({
                tenant_id: t.tenantId,
                tenant_name: licenseMap.get(t.tenantId) || 'Unknown',
                intent_score: t.intentScore,
                intent_level: t.intentLevel,
                usage_growth_percent: t.usageGrowthPercent,
                last_calculated_at: t.lastCalculatedAt
            }))
        };
    },
    async getMonthSnapshot(db, _month) {
        return this.getOverview(db);
    },
    async getTenantMonth(db, tenantId, _month) {
        const record = await db.upgradeIntelligence.findUnique({
            where: { tenantId }
        });
        if (!record)
            return null;
        const license = await db.license.findUnique({
            where: { id: tenantId },
            select: { schoolName: true }
        });
        return {
            tenant_id: record.tenantId,
            tenant_name: license?.schoolName || 'Unknown',
            intent_score: record.intentScore,
            intent_level: record.intentLevel,
            usage_growth_percent: record.usageGrowthPercent,
            last_calculated_at: record.lastCalculatedAt
        };
    }
};
